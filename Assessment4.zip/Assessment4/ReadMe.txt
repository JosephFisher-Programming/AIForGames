All of these test the functions required by the Assessment.
The bubble sort sorts them and outputs how many times it looped.
Double Linked Lists are added to, substracted, copied, and resized.
The Hash Function stores a value of 99 in Array One under "Terry", and Array Two copies it.